package edu.siu.fireprevention.Driver;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.sql.Connection;
import java.util.ArrayList;

import edu.siu.fireprevention.Driver.*;
import net.sourceforge.jFuzzyLogic.FIS;


/**
 * Servlet implementation class firePrevention
 */
public class FirePrevention extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public static final String  fclFile = "src/edu/siu/fireprevention/Driver/fuzzyLogicProcess.fcl";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FirePrevention() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// System.out.print("----------------HELLO GET-------------------"); 
		FirePreventionDriver FPD = new FirePreventionDriver();  		
	    FPD.popData(); 		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	    
        // System.out.print("----------------HELLO POST-------------------"); 
		PrintWriter out = response.getWriter();
		FirePreventionDriver FPD = new FirePreventionDriver(); 
		ArrayList<String> riskVal = new ArrayList<String>(); 	
		String outPutStr = "";
		FPD.popData();
					
		riskVal = FPD.getRiskVal("C:\\Users\\siu853639004\\workspace\\testFirePre\\WebContent\\fuzzyLogicProcess.fcl"); 				
		for(String s:riskVal){
			outPutStr += s + "\t"; 		
		}
		// System.out.println(outPutStr);
		out.print(outPutStr); 			
		
		
	}

}
