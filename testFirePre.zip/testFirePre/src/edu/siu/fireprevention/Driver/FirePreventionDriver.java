package edu.siu.fireprevention.Driver;

import java.io.InputStream;
import java.sql.Connection;
import java.util.ArrayList;

import edu.siu.fireprevention.Driver.*;
import net.sourceforge.jFuzzyLogic.FIS;
import net.sourceforge.jFuzzyLogic.plot.JFuzzyChart;

public class FirePreventionDriver {

	/**
	 * @param args
	 */
	
// 	public static final String  fclFile = "src/edu/siu/fireprevention/Driver/fuzzyLogicProcess.fcl"; 
	
/*	public static void main(String[] args) {
		// TODO Auto-generated method stub
				
		popData(); 
				
		while(2>1){
			
			getRiskVal(fclFile);
			sleep(12000); 		
			System.out.println("--------------------------------");
		}

		
		
	}*/
	
	public void sleep(int secs){
		
		  try { 
			   Thread.sleep(secs);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}  
		
	}

	public ArrayList<String> getRiskVal(String is) {
		
		DataDriver srcData = new DataDriver();
		AnalysisDriver riskPre = new AnalysisDriver(); 
		ArrayList<String>  records = new ArrayList<String>();
		ArrayList<String>  records1 = new ArrayList<String>();
		ArrayList<String>  res = new ArrayList<String>();
		String[]  attrs;
		String[]  attrs1;
		double riskVal;
		String cityName = null;
		
		Connection conn = srcData.conn("jdbc:oracle:thin:@localhost:1521:orcl",
						 "hr", "oracle2015"); 
		records = srcData.getData(conn, "SRCDATA"); 
		
		
		for(String s:records){
			
			attrs = s.split("\t"); 
			riskVal = riskPre.fuzzyLogicProcess(is,  Double.parseDouble(attrs[0]), Double.parseDouble(attrs[1]), Double.parseDouble(attrs[2])); 
			conn = srcData.conn("jdbc:oracle:thin:@localhost:1521:orcl",
					 "hr", "oracle2015"); 
			records1 = srcData.getData(conn, "CITY", attrs[3]); 
			for(String s1:records1){
				attrs1 = s1.split("\t"); 
				if(attrs1[0].equals(attrs[3])){
					cityName = attrs1[1]; 
					break; 
				}			
			}
			res.add(cityName + ":" + riskVal); 
			System.out.println(cityName + ": " + riskVal); 
			cityName = null; 
		}
		return res; 
	}

	public void popData() {
		Thread t = new Thread(){
			public void run(){
				DataDriver srcData = new DataDriver();
				srcData.popData("jdbc:oracle:thin:@localhost:1521:orcl",
						 "hr", "oracle2015", "SRCDATA", 3, 6000);
			}		
		}; 
		
		t.start();
	}

}
