package edu.siu.fireprevention.Driver;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;

import net.sourceforge.jFuzzyLogic.FIS;
import net.sourceforge.jFuzzyLogic.plot.JFuzzyChart;


public class AnalysisDriver {
		
	public double fuzzyLogicProcess(String fileName, double T, double W, double H) {
		
		FIS fis = FIS.load(fileName,true);
		// Error while loading?
        if( fis == null ) { 
            System.err.println("Can't load file: '" + fileName + "'");
            return 1;
        }

		fis.setVariable("T",T);
		fis.setVariable("W",W);
		fis.setVariable("H",H);
		
		//Evaluate
		fis.evaluate();
		
		
		//get output
		double R = fis.getVariable("R").getLatestDefuzzifiedValue();
		  // System.out.println(Math.cos(heading));
		return R; 
	}
	
}

