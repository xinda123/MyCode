package edu.siu.fireprevention.Driver; 

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.util.ArrayList;

import edu.siu.fireprevention.dboper.*; 

public class DataDriver implements DbOper{



	/**
	 * @param args
	 */
/*	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		popData("jdbc:oracle:thin:@localhost:1521:orcl",
				 "hr", "oracle2015", "SRCDATA", 3, 6000); 

	}*/
	
	
	

	public Double dataGenerator(double min,double max) {		
		
		return Double.parseDouble(new DecimalFormat("##.##").format((max - min)*Math.random() + min));
	}
	
@Override 
	public Connection conn(String connStr, String userName, String passwd) {
		// TODO Auto-generated method stub		 
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			Connection conn = DriverManager.getConnection (connStr,
					userName, passwd);
			return conn; 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return null; 
	}

@Override 
	public void popData(String connStr, String userName, String passwd, String tableName, int numOfObject, int freshFrequency) {
		// TODO Auto-generated method stub
		
		Double T,H,W; 
		String[] sqlStr = new String[numOfObject]; 
		int k; 
		Connection conn = conn(connStr,userName,passwd); 
		
		
		while (2>1){
			
			k = numOfObject; 
			while(k > 0){
				
				T = dataGenerator(-40,40);
				H = dataGenerator(0.1,0.9); 
				W = dataGenerator(0,90); 		
				sqlStr[k-1] = "UPDATE " + tableName +  
						       " SET " + 
						       "TEMPERATURE = " + T + ", " + 
						       "HUMIDITY = " + H + ", " + 
						       "WIND_SPEED = " + W + 
						       " WHERE " + "CITY_ID = " + k; 
				k--; 
				// System.out.println(sqlStr[k-1]);
			}
			
		
			for(String s:sqlStr){
				
				// System.out.println(s);	
				
				try {
					
								
					Statement stmt = conn.createStatement(); 
					int codeid = stmt.executeUpdate(s); 
					
					if(codeid != 1) 
						System.out.println("Add failuer! ORA-02291: integrity constraint  violated - parent key not found ");
/*					else
						System.out.println("Add failuer! ORA-02291: integrity constraint  violated - parent key not found ");*/
					conn.close(); 
					conn = conn(connStr,userName,passwd);  
				    
				} catch (SQLException e) {
					// TODO: handle exception
					System.out.println(e.toString());
				}catch (Exception e) {
					// TODO: handle exception
					System.out.println(e.toString());
				}
				
			}
			
	  try { 
			   Thread.sleep(freshFrequency);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}   
					
		}
		
	}

@Override
public ArrayList<String> getData(Connection conn, String tableName) {
	// TODO Auto-generated method stub
	
	
	
	try {		
		ArrayList<String> records = new ArrayList<String>();		
		
		String sqlStr = "SELECT * FROM " + tableName; 
		// System.out.println(sqlStr);
		
		Statement stmt = conn.createStatement(); 
		ResultSet rset = stmt.executeQuery(sqlStr); 
	    
	    ResultSetMetaData rsmd = rset.getMetaData();

	    int numCols = rsmd.getColumnCount();
	    
	    String tuple="";	    
	    while(rset.next()){    	
	    	for(int i = 1; i <= numCols; i++){
	    		if(i == numCols)
	    			tuple += rset.getString(i);
	    		else
	    			tuple += rset.getString(i) + "\t";     		
	    	} 
	    	records.add(tuple);
	    	tuple = "";  	    
	    }
	    	      
	    conn.close();
	    return records; 
			
	} catch (SQLException e) {
		// TODO: handle exception
		System.out.println(e.toString());
	}catch (Exception e) {
		// TODO: handle exception
		System.out.println(e.toString());
	}
	return null;
}

@Override
public ArrayList<String> getData(Connection conn, String tableName, String cond) {
	// TODO Auto-generated method stub
		
	try {		
		ArrayList<String> records = new ArrayList<String>();		
		
		String sqlStr = "SELECT * FROM " + tableName + " WHERE ID = " + cond; 
//		System.out.println(sqlStr);
		
		Statement stmt = conn.createStatement(); 
		ResultSet rset = stmt.executeQuery(sqlStr); 
	    
	    ResultSetMetaData rsmd = rset.getMetaData();

	    int numCols = rsmd.getColumnCount();
	    
	    String tuple="";	    
	    while(rset.next()){    	
	    	for(int i = 1; i <= numCols; i++){
	    		if(i == numCols)
	    			tuple += rset.getString(i);
	    		else
	    			tuple += rset.getString(i) + "\t";     		
	    	} 
	    	records.add(tuple);
	    	tuple = "";  	    
	    }
	    	      
	    conn.close();
	    return records; 
			
	} catch (SQLException e) {
		// TODO: handle exception
		System.out.println(e.toString());
	}catch (Exception e) {
		// TODO: handle exception
		System.out.println(e.toString());
	}
	return null;
}
	
}
