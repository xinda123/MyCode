package edu.siu.fireprevention.dboper;

import java.sql.Connection;
import java.util.ArrayList;


public interface DbOper { 
	Connection conn(String connStr, String userName, String passwd);
	ArrayList<String> getData(Connection conn, String tableName); 
	ArrayList<String> getData(Connection conn, String tableName, String cond); 
	void popData(String connStr, String userName, String passwd, String tableName, int numOfObject, int freshfrequency);
	
}
